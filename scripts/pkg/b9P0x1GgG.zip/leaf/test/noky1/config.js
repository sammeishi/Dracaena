module.exports = {
    "des":"this is noky1 des",
};